INSERT INTO `wp_messages` VALUES (1, 100004, 1, '测试1', '测试内容1', 1, 1, '2018-7-12 11:22:57');
INSERT INTO `wp_messages` VALUES (2, 100004, 1, '测试2', '测试内容2', 1, 1, '2018-7-12 11:22:57');
