INSERT INTO `wp_my_coach` VALUES (1, 3, 354, 9, NULL, 1);
INSERT INTO `wp_my_coach` VALUES (2, 3, 355, 9, NULL, 1);
INSERT INTO `wp_my_coach` VALUES (3, 3, 260, 4, NULL, 1);
INSERT INTO `wp_my_coach` VALUES (4, 3, 354, 10, NULL, NULL);
