INSERT INTO `wp_match_team` VALUES (1, 407, 3, 2);
