INSERT INTO `wp_coach_skill` VALUES (1, 9, 354, 355, 260);
INSERT INTO `wp_coach_skill` VALUES (2, 10, 354, 355, NULL);
INSERT INTO `wp_coach_skill` VALUES (3, 8, 354, NULL, NULL);
INSERT INTO `wp_coach_skill` VALUES (4, 4, NULL, 355, 260);
