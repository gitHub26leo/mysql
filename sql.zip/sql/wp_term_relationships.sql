INSERT INTO `wp_term_relationships` VALUES (1, 1, 0);
