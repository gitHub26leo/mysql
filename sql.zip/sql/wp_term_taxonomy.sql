INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1);
