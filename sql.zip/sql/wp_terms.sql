INSERT INTO `wp_terms` VALUES (1, '未分类', 'uncategorized', 0);
