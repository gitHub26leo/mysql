INSERT INTO `wp_my_address` VALUES (1, 3, 'leo', '15982345102', NULL, '四川省', '成都市', '武侯区', '桐梓林丰德万瑞', NULL, NULL, NULL, 1);
INSERT INTO `wp_my_address` VALUES (2, 3, 'leo', '15982345102', NULL, '四川省', '成都市', '高新区', '锦城广场环球中心', NULL, NULL, NULL, NULL);
