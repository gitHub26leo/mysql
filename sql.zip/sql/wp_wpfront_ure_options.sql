INSERT INTO `wp_wpfront_ure_options` VALUES (1, 'wp_wpfront_ure_options-db-version', '2.14.1');
INSERT INTO `wp_wpfront_ure_options` VALUES (2, 'attachment_capabilities_processed', '1');
INSERT INTO `wp_wpfront_ure_options` VALUES (3, 'user_permission_capabilities_processed', '1');
INSERT INTO `wp_wpfront_ure_options` VALUES (4, 'wp_wpfront_ure_login_redirect-db-version', '2.14.1');
